import re
import pprint
import random
import pyttsx3
import requests
from bs4 import BeautifulSoup
import datetime
import tkinter as tk
from tkinter import scrolledtext

# Initialize text-to-speech engine
engine = pyttsx3.init()

class arvisAssistant:
    # Define the constructor
    def __init__(self):
        self.weather_api_key = "your_weather_api_key"
        self.weather_base_url = "http://api.openweathermap.org/data/2.5/weather?"

    def get_weather(self, city):
        # Fetch weather data from OpenWeatherMap API
        url = self.weather_base_url + "q=" + city + "&appid=" + self.weather_api_key
        response = requests.get(url)
        data = response.json()

        # Convert temperature from Kelvin to Celsius
        temperature = round(data["main"]["temp"] - 273.15, 1)

        # Get weather description
        description = data["weather"][0]["description"]

        # Return weather data as a string
        return f"The weather in {city} is {temperature}°C with {description}."

    def website_opener(self, url):
        # Open the website in the default browser
        import webbrowser
        webbrowser.open(url)

    def launch_any_app(self, path_of_app):
        # Launch the application using the default operating system command
        import subprocess
        subprocess.Popen(path_of_app)

    def tell_me(self, topic):
        # Fetch information from Wikipedia
        url = "https://en.wikipedia.org/wiki/" + topic
        response = requests.get(url)
        soup = BeautifulSoup(response.text, "html.parser")
        paragraphs = soup.find_all("p")
        result = ""
        for paragraph in paragraphs:
            result += paragraph.text
        return result[:1000] + "..."

    def tell_me_date(self):
        # Get the current date
        return datetime.date.today().strftime("%B %d, %Y")

    def tell_me_time(self):
        # Get the current time
        return datetime.datetime.now().strftime("%H:%M:%S")

def t2s(text):
    engine.say(text)
    engine.runAndWait()

class AssistantGUI:
    def __init__(self, master):
        self.master = master
        master.title("arvisAssistant")

        self.text_box = scrolledtext.ScrolledText(master, width=100, height=30)
        self.text_box.pack(padx=10, pady=10)

        self.entry_box = tk.Entry(master, width=100)
        self.entry_box.pack()

        self.button = tk.Button(master, text="Send", command=self.send_command)
        self.button.pack()

    def send_command(self):
        user_input = self.entry_box.get()
        self.text_box.insert(tk.END, "You: " + user_input + "\n")

        try:
            if re.search('weather|temperature', user_input):
                city = user_input.split(' ')[-1]
                weather_res = obj.get_weather(city)
                self.text_box.insert(tk.END, "Assistant: " + weather_res + "\n")
                print(weather_res)  # Print the result for text output

            if re.search('news', user_input):
                # Fetch news from a news website
                url = "https://www.cnn.com/"
                response = requests.get(url)
                soup = BeautifulSoup(response.text, "html.parser")
                headlines = soup.find_all("h3", class_="card-title")
                self.text_box.insert(tk.END, "Assistant: I have found {} news. You can read it. Let me tell you the first 2 of them\n".format(len(headlines)))
                print("Assistant: I have found {} news. You can read it. Let me tell you the first 2 of them".format(len(headlines)))  # Print the result for text output
                self.text_box.insert(tk.END, "Assistant: " + headlines[0].text + "\n")
                self.text_box.insert(tk.END, "Assistant: " + headlines[1].text + "\n")
                print("Assistant: " + headlines[0].text)  # Print the result for text output
                print("Assistant: " + headlines[1].text)  # Print the result for text output

            if re.search('tell me about', user_input):
                topic = user_input.split(' ')[-1]
                wiki_res = obj.tell_me(topic)
                self.text_box.insert(tk.END, "Assistant: " + wiki_res + "\n")
                print("Assistant: " + wiki_res)  # Print the result for text output

            if re.search('date', user_input):
                date = obj.tell_me_date()
                self.text_box.insert(tk.END, "Assistant: " + date + "\n")
                print("Assistant: " + date)  # Print the result for text output

            if re.search('time', user_input):
                time = obj.tell_me_time()
                self.text_box.insert(tk.END, "Assistant: " + time + "\n")
                print("Assistant: " + time)  # Print the result for text output

            if re.search('open', user_input):
                domain = user_input.split(' ')[-1]
                open_result = obj.website_opener(domain)
                self.text_box.insert(tk.END, "Assistant: " + open_result + "\n")

            if re.search('launch', user_input):
                dict_app = {
                    'chrome': 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
                    'epic games': 'C:\\Program Files (x86)\\Epic Games\\Launcher\\Portal\\Binaries\\Win32\\EpicGamesLauncher.exe'
                }

                app = user_input.split(' ', 1)[1]
                path = dict_app.get(app)
                if path is None:
                    print('Assistant: Application path not found')  # Print the result for text output
                else:
                    print('Assistant: Launching: ' + app)  # Print the result for text output
                    obj.launch_any_app(path_of_app=path)

            if re.search('hello', user_input):
                self.text_box.insert(tk.END, "Assistant: Hi\n")
                print("Assistant: Hi")  # Print the result for text output

            if re.search('how are you', user_input):
                li = ['good', 'fine', 'great']
                response = random.choice(li)
                self.text_box.insert(tk.END, "Assistant: I am " + response + "\n")
                print("Assistant: I am " + response)  # Print the result for text output

            if re.search('your name|who are you', user_input):
                self.text_box.insert(tk.END, "Assistant: My name is Jarvis, I am your personal assistant\n")
                print("Assistant: My name is Jarvis, I am your personal assistant")  # Print the result for text output

            if re.search('what can you do', user_input):
                li_commands = {
                    "open websites": "Example: 'open youtube.com",
                    "time": "Example: 'what time it is?'",
                    "date": "Example: 'what date it is?'",
                    "launch applications": "Example: 'launch chrome'",
                    "tell me": "Example: 'tell me about India'",
                    "weather": "Example: 'what weather/temperature in Mumbai?'",
                    "news": "Example: 'news for today' ",
                }
                ans = """I can do lots of things, for example you can ask me time, date, weather in your city,
                I can open websites for you, launch application and more. See the list of commands-\n"""
                self.text_box.insert(tk.END, ans)
                print(ans)  # Print the result for text output

        except Exception as e:
            self.text_box.insert(tk.END, "Error: " + str(e) + "\n")
            print("Error: " + str(e))  # Print the error for text output

root = tk.Tk()
obj = arvisAssistant()
app = AssistantGUI(root)
root.mainloop()
