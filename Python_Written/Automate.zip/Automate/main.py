import tkinter as tk
import pyttsx3
import threading
import random
import queue
import nltk
from nltk.corpus import wordnet


# Create a SAPI voice
engine = pyttsx3.init('sapi5')

# Use a specific voice (requires voice name as shown in the Windows settings)
def speak(audio):
    engine.setProperty('voice', 'Microsoft Zira Desktop')

    # Speak some text in a separate thread
    threading.Thread(target=speak_thread, args=(audio,)).start()

def speak_thread(audio):
    # Speak some text
    engine.say(audio)

    # Wait for the speech to finish
    engine.runAndWait()

# Set the name of the AI assistant
name = "Python"

# Define some responses for common greetings
greeting_responses = [
    "Hi there!",
    "Hello!",
    "Hey!",
    "What's up?",
]

# Define some responses for farewells
farewell_responses = [
    "Goodbye!",
    "See you later!",
    "Take care!",
]

# Define some responses for random topics
topic_responses = [
    "That's interesting!",
    "Can you tell me more about that?",
    "I don't know much about that, but it sounds cool!",
]

# Define some responses for questions about the AI assistant
ai_responses = [
    "I'm just a simple AI assistant designed to help you with some basic tasks.",
    "I'm not a real person, but I'm here to assist you in any way I can.",
    "I'm just a program running on a computer, but I'm happy to help you!",
]

def start_conversation():
    # Create a queue to store the responses that need to be spoken
    response_queue = queue.Queue()

    # Start a thread to speak the responses from the queue
    threading.Thread(target=speak_thread, args=(response_queue,)).start()

    while True:
        user_input = input_box.get().lower()

        if user_input.lower() == "quit":
            break

        # Perform some action based on user input
        response = generate_response(user_input)

        # Add the response to the queue
        response_queue.put(response)

        # Display the response in the Tkinter window
        response_label.config(text=response)
        window.update_idletasks()

def speak_thread(response_queue):
    while True:
        # Get the next response from the queue
        response = response_queue.get()

        # Speak the response
        speak(response)

# Create a Tkinter window
window = tk.Tk()

# Create a text input box
input_box = tk.Entry(window)
input_box.pack()

# Create a label to display the AI's response
response_label = tk.Label(window, text="")
response_label.pack()

# Create a button to start the conversation
start_button = tk.Button(window, text="Start Conversation", command=start_conversation)
start_button.pack()

# Start the Tkinter event loop
window.mainloop()


star_converstation()
